export const environment = {
  production: true,
  url: 'http://3.236.170.13:8080/api'
};
