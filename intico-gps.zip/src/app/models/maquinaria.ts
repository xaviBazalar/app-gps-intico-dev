interface IData {
    result: [];
    invoiceNumber: string;
    totalAmount: number;
}