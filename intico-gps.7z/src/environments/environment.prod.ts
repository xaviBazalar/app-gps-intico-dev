export const environment = {
  production: true,
  //url: 'http://localhost:8080/api',//'http://3.236.170.13:8080/api',
  url: 'http://44.192.39.42:8080/api',
  urlFlespi: 'https://flespi.io/gw/devices'
};
